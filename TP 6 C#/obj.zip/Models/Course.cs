﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_6_C_.Models
{
    class Course
    {
        public int Id { get; set; }          // Clé primaire
        public string Title { get; set; } // Prénom
        public string Credits { get; set; }  // Nom
    }
}
